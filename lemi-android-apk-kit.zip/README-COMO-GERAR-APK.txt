LE & MI CONTROLE DE CONTAS PESSOAIS — SUBIR PARA O GITHUB E GERAR O APK AUTOMATICAMENTE

Este ZIP já inclui a automação (.github/workflows/build-apk.yml) que compila o APK Android
automaticamente na nuvem do GitHub assim que você enviar os arquivos.

PASSO A PASSO NO GITHUB (SEM PRECISAR DE ANDROID STUDIO):
1. Crie um repositório novo no GitHub (https://github.com/new), por exemplo: lemi-controle-contas.
2. Extraia este ZIP em uma pasta no seu computador.
3. Envie os arquivos para o repositório:
   - Pelo navegador: clique em "uploading an existing file", arraste todos os arquivos/pastas
     (inclusive a pasta oculta .github) e clique em "Commit changes".
   - Ou pelo terminal dentro da pasta extraída:
       git init
       git add .
       git commit -m "Versao inicial Le & Mi Controle de Contas"
       git branch -M main
       git remote add origin https://github.com/SEU_USUARIO/lemi-controle-contas.git
       git push -u origin main
4. No GitHub, abra a aba "Actions" -> clique na execução "Build Android APK (Le & Mi Contas)".
5. Quando terminar (~2 a 3 minutos), role até "Artifacts" e baixe "Le-Mi-Controle-Contas-APK"
   contendo o arquivo app-debug.apk pronto para instalar no seu Android!
